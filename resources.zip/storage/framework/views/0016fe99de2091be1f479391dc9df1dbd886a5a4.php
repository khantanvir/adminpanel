
<?php $__env->startSection('admin'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Create sub-category</h4>
                </div>
                <form method="post" action="<?php echo e(URL::to('store-subcategory')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="basic-form">
                            <input type="hidden" name="subcategory_id" value="<?php echo e((!empty($sub_category->id))?$sub_category->id:''); ?>" class="form-control input-default ">
                            <h4 class="card-title">Title</h4>
                            <div class="mb-3">
                                <input type="text" name="title" value="<?php echo e((!empty($sub_category->title))?$sub_category->title:''); ?>" class="form-control input-default ">
                                <?php if($errors->has('title')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                                <?php endif; ?>
                            </div><br>
                            <h4 class="card-title">Discription</h4>
                            <div class="mb-3">
                                <textarea name="description" class="form-control" rows="4" id="comment"><?php echo e((!empty($sub_category->description))?$sub_category->description:''); ?></textarea>
                                <?php if($errors->has('description')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                                <?php endif; ?>
                            </div><br>
                            <div class="mb-3">
                                <h4 class="card-title">Select Category</h4>
                                <select name="category_id" class="default-select form-control wide mb-3">
                                    <option value="">Select Category</option>
                                    <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e((!empty($sub_category->category_id) && $sub_category->category_id==$row->id)?'selected':''); ?> value="<?php echo e($row->id); ?>"><?php echo e($row->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('category_id')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('category_id')); ?></span>
                                <?php endif; ?>
                            </div><br>
                            <button type="submit" class="btn btn-primary">Add</button>
                     </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\adminpanel\resources\views/category/createSubcategory.blade.php ENDPATH**/ ?>