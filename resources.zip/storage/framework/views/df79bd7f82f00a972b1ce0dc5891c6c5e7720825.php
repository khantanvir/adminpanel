
<?php $__env->startSection('admin'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">User Role List</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-responsive-md">
                            <thead>
                                <tr>
                                    <th><strong>Id No.</strong></th>
                                    <th><strong>Name</strong></th>
                                    <th><strong>Create Date</strong></th>
                                    <th><strong>Status</strong></th>
                                    <th><strong>Action</strong></th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="<?php echo e((!empty(Session::get('role_id')) && Session::get('role_id')==$row->id)?'table-primary':''); ?>">
                                    <td><strong><?php echo e($row->id); ?></strong></td>
                                    <td><?php echo e($row->name); ?>	</td>
                                    <td><?php echo e($row->created_at); ?></td>
                                    <td>
                                        <?php if($row->status==0): ?>
                                            <span class="badge light badge-success">Activate</span>
                                        <?php else: ?>
                                        <span class="badge light badge-danger">Deactivate</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="d-flex">
                                            <?php if($row->status==0): ?>
                                            <a href="javascript:void(0)" onclick="if(confirm('Are you sure to Deactivate this Role?')) location.href='<?php echo e(URL::to('role/deactivate/'.$row->id)); ?>'; return false;" title="Deactivate" href="#" class="btn btn-danger shadow btn-xs sharp me-1"><i class="fas fa-duotone fa-toggle-off"></i></a>
                                            <?php else: ?>
                                            <a href="javascript:void(0)" onclick="if(confirm('Are you sure to Activate this Role?')) location.href='<?php echo e(URL::to('role/activate/'.$row->id)); ?>'; return false;" title="Activate" href="#" class="btn btn-warning shadow btn-xs sharp me-1"><i class="fas fa-toggle-on"></i></a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="bg-danger text-white p-1">No Item Found</p>
                                <?php endif; ?>
                                
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\adminpanel\resources\views/Role/all.blade.php ENDPATH**/ ?>